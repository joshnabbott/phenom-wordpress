    <footer class="row-fluid">
      <p class="pull-right">&copy; 2012 PHENOM&trade;. All rights reserved. <a href="http://wordpress.org/" rel="generator">Powered by WordPress</a> and a whole lotta love.</p>
    </footer>
  </div><!-- end primary-container -->
  <?php wp_footer(); ?>
</body>
</html>

