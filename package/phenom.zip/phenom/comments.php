<?php
// Default comments file goes here